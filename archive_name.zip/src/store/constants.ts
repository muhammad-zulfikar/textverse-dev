// constants.ts

export const DEFAULT_FOLDERS = {
  ALL_NOTES: 'All Notes',
  UNCATEGORIZED: 'Uncategorized',
};
